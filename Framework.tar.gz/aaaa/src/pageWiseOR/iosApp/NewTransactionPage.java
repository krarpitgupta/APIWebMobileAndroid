package pageWiseOR.iosApp;

public class NewTransactionPage {

}
