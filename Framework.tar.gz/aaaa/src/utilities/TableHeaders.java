package utilities;

public enum TableHeaders {

	CompanyName,
	LTP,
	QuantAvgCost, 
	Change, 
	ChangePercent, 
	AmmountInvested, 
	CurrentValue, 
	TodaysGainLoss, 
	NotionalGainLoss, 
	SchemeMF, 
	LastNAVMF, 
	UnitsAvgCostMF, 
	ChangeMF, 
	ChangePercentMF, 
	InvetsedAmountMF, 
	CurrentValueMF, 
	TodaysGainLossMF, 
	NotionalGainLossMF

}
