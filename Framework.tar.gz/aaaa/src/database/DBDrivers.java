package database;

public interface DBDrivers {

	String JDBCDriver = "com.mysql.jdbc.Driver";
	String ConnectionUrl = "jdbc:mysql://192.168.24.154:3306/etpm_db";
	String DbUser = "MohdNaziM";
	String DbPass = "MohdNaziM@43";
	/*String JDBCDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	String ConnectionUrl = "jdbc:sqlserver://192.168.25.179";
	String DbUser = "dewreaduser";
	String DbPass = "Dewu$er@109";*/
}
